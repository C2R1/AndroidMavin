/** Automatically generated file. DO NOT MODIFY */
package fr.stage.android.arduino;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}